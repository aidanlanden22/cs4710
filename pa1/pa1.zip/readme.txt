Programing Assignment 1 - Theorem Prover
CS4710 Artificial Intelligence
Leiqing Cai (Lc9ac)


The program can be run by:  python pa1.py
To redirect input:          python pa1.py < input_file



